import os
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import requests

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
GOOGLE_CUSTOM_SEARCH_API_KEY = os.getenv("GOOGLE_CUSTOM_SEARCH_API_KEY")
SEARCH_ENGINE_ID = os.getenv("SEARCH_ENGINE_ID")
GOOGLE_DRIVE_API_KEY = os.getenv("GOOGLE_DRIVE_API_KEY")

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hello! I can search the web & get Google Drive file info.\nUse /search <query> or /drive <file_id>")

async def search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = " ".join(context.args)
    if not query:
        await update.message.reply_text("Please provide a search query.")
        return
    url = f"https://www.googleapis.com/customsearch/v1?q={query}&key={GOOGLE_CUSTOM_SEARCH_API_KEY}&cx={SEARCH_ENGINE_ID}"
    try:
        resp = requests.get(url).json()
        items = resp.get("items", [])
        if not items:
            await update.message.reply_text("No results found.")
            return
        message = "\n\n".join([f"{item['title']}\n{item['link']}" for item in items[:5]])
        await update.message.reply_text(message)
    except Exception as e:
        await update.message.reply_text(f"Error: {str(e)}")

async def drive(update: Update, context: ContextTypes.DEFAULT_TYPE):
    file_id = " ".join(context.args)
    if not file_id:
        await update.message.reply_text("Please provide a Google Drive file ID.")
        return
    url = f"https://www.googleapis.com/drive/v3/files/{file_id}?key={GOOGLE_DRIVE_API_KEY}&fields=id,name,mimeType,webViewLink"
    try:
        resp = requests.get(url).json()
        if "error" in resp:
            await update.message.reply_text(f"Error: {resp['error']['message']}")
            return
        message = f"📄 Name: {resp['name']}\nType: {resp['mimeType']}\nLink: {resp['webViewLink']}"
        await update.message.reply_text(message)
    except Exception as e:
        await update.message.reply_text(f"Error: {str(e)}")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", start))
    app.add_handler(CommandHandler("search", search))
    app.add_handler(CommandHandler("drive", drive))
    print("Bot running...")
    app.run_polling()
