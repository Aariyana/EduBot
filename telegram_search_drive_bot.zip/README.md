# Telegram Search & Drive Bot

## Setup
1. Clone repository or download ZIP.
2. Create `.env` file with your real keys:
```
TELEGRAM_BOT_TOKEN=123456:ABC-xyz
GOOGLE_CUSTOM_SEARCH_API_KEY=AIza...
SEARCH_ENGINE_ID=abcd1234
GOOGLE_DRIVE_API_KEY=AIza...
```
3. Install dependencies:
```
pip install -r requirements.txt
```
4. Run bot:
```
python main.py
```
